import {
  ArrowRight,
  CalendarClock,
} from "lucide-react";

import type {
  PerformanceAttempt,
} from "./types";

import {
  formatDateTime,
} from "./helpers";

import ExamTypeBadge from "./ExamTypeBadge";
import CountdownTimer from "./CountdownTimer";

interface UpcomingResultCardProps {
  item: PerformanceAttempt;
  onClick: () => void;
}

const UpcomingResultCard = ({
  item,
  onClick,
}: UpcomingResultCardProps) => {
  const releaseDate =
    item.resultReleaseDate;

  return (
    <button
      type="button"
      onClick={onClick}
      className="group w-full overflow-hidden rounded-3xl border border-purple-100 bg-white text-left shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-purple-300 hover:shadow-xl"
    >
      <div className="h-1.5 bg-gradient-to-r from-purple-700 via-purple-500 to-orange-400" />

      <div className="p-5 sm:p-6">

        <div className="flex flex-col gap-5">

          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <h3 className="text-lg font-black text-slate-900">
                {item.exam.title}
              </h3>

              <p className="mt-1 text-xs text-slate-500">
                {item.exam.department}
              </p>

              <div className="mt-3">
                <ExamTypeBadge
                  type={
                    item.exam.examType
                  }
                  mode={
                    item.exam.examMode
                  }
                />
              </div>
            </div>

            <span className="shrink-0 rounded-full bg-orange-50 px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-orange-700">
              Published
            </span>
          </div>

          <div className="rounded-2xl border border-purple-100 bg-purple-50/50 p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-purple-700 shadow-sm">
                <CalendarClock
                  size={18}
                />
              </div>

              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-purple-600">
                  Result will be released on
                </p>

                <p className="mt-1 text-sm font-black text-slate-800">
                  {formatDateTime(
                    releaseDate
                  )}
                </p>
              </div>
            </div>

            <div className="mt-4">
              <CountdownTimer
                deadline={
                  releaseDate
                }
              />
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 pt-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Attempt
              </p>

              <p className="mt-1 text-xs font-bold text-slate-600">
                Attempt{" "}
                {item.attempt.attemptNo}
              </p>
            </div>

            <span className="inline-flex items-center gap-2 text-xs font-extrabold text-purple-700 transition group-hover:text-orange-500">
              View Examination
              <ArrowRight size={15} />
            </span>
          </div>

        </div>
      </div>
    </button>
  );
};

export default UpcomingResultCard;